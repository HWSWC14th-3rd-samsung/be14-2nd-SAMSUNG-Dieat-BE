package com.samsung.dieat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DieatmemberApplicationTests {

	@Test
	void contextLoads() {
	}

}
