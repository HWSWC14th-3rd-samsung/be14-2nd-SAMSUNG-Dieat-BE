//package com.samsung.dieat.member.command.infrastructure.service;
//
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.GetMapping;
//
//@FeignClient(name = "food-data-service-get", url="localhost:8000")
//public class FoodDataServiceClient {
//    @GetMapping("/{userId}/food-data")
//    List<ResponseFooddata>
//
//}
