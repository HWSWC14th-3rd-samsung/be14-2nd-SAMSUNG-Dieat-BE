package com.samsung.dieat.member.command.application.dto;

import lombok.Data;

@Data
public class EmailSendRequestDTO {
    private String email;
}
