package com.samsung.dieat.member.command.domain.aggregate.vo;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ResponseRegistUserVO {
    private String userName;
    private String userNickname;

}
