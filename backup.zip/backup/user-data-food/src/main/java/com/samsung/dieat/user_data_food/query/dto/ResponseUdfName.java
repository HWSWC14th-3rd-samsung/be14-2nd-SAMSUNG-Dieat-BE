package com.samsung.dieat.user_data_food.query.dto;

import lombok.Data;

@Data
public class ResponseUdfName {
    private String udfName;
}
