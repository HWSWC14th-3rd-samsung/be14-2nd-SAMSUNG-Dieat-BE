package com.samsung.dieat.like.command.domain.entity;

public enum LikesTargetType {
    FREE,
    DIET,
    SUCCESS
}
