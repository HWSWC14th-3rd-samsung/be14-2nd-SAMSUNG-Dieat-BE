package com.samsung.dieat.comment.command.domain.entity;

public enum CommentTargetType {
    FREE, DIET, SUCCESS
}
