package com.samsung.dieat.meal.query.service;

import com.samsung.dieat.meal.command.domain.aggregate.entity.MealFood;

public interface MealFoodQueryService {

}
