package com.samsung.dieat.comment.command.application.dto;

import lombok.Data;

@Data
public class CommentUpdateDTO {
    private int cmtCode;
    private String cmtConts;
}
