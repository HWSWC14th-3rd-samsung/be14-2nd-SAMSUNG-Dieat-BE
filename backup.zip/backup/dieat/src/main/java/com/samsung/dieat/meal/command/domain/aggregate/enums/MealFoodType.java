package com.samsung.dieat.meal.command.domain.aggregate.enums;

public enum MealFoodType {
    OPENDATA, USERDATA
}
