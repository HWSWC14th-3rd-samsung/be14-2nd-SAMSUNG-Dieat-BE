package com.samsung.dieat.meal.query.dao;

public class MealQueryRepositoryImpl {
}
