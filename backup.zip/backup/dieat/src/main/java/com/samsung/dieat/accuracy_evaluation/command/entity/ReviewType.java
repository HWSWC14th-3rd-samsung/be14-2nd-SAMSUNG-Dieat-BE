package com.samsung.dieat.accuracy_evaluation.command.entity;

public enum ReviewType {
    ACCURATE, INACCURATE
}
