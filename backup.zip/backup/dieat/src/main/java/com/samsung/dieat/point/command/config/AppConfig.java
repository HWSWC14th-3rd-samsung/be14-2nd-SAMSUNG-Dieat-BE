package com.samsung.dieat.point.command.config;//package com.samsung.dieat.point.command.config;
//
//
//import com.samsung.dieat.point.command.application.dto.PointDTO;
//import com.samsung.dieat.point.command.domain.aggregate.entity.PointEntity;
//import org.modelmapper.ModelMapper;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class AppConfig {
//
//    @Bean
//    public ModelMapper modelMapper() {
//        return new ModelMapper();
//    }
//}
