package com.samsung.dieat.accuracy_evaluation.command.application.dto;

import lombok.Data;

@Data
public class UserDataFoodReviewRequest {
    private int rvwUserCode;
    private int udfCode;
}
