package com.samsung.dieat.meal.command.domain.repository;

public interface MealCommandMapper {
}
