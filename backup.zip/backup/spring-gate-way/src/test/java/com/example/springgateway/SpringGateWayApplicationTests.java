package com.example.springgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGateWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
